# Cours React en français sur OpenClassrooms

Ce dépôt sert de support au cours francophone React sur [OpenClassrooms](https://openclassrooms.com/).

Il contient toute une série de tags permettant de récupérer le code d’une étape, finalisé, mais aussi d’aller récupérer des feuilles de style et squelettes de code pour certains chapitres du cours afin de se concentrer sur le savoir-faire du chapitre.

© 2017 [Delicious Insights](https://delicious-insights.com/)

Ce support est distribué sous licence MIT.  Le cours OpenClassrooms est mis à disposition sous licence Creative Commons.

Bon apprentissage à tou·te·s ! 😁
